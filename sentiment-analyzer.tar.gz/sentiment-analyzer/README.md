# AI-Based Intelligent Customer Feedback Analyzer
## with Sentiment Confidence Scoring

**Team:** Ruttala Mohan (RA221102620002) | Ganthi Nethaji (RA2211026020058) | Bommisetty Rohith (RA2211026020041)
**Supervisor:** Dr. R. Angeline, Dept. of CSE(AIML), SRM University

---

## Structure (FLAT — no backend/ subfolder issues)

```
your-repo/                  ← THIS is the Git repo root
├── Dockerfile              ← Uses COPY . /app/ (copies everything)
├── .dockerignore
├── .gitignore
├── railway.json
├── README.md
├── app.py                  ← Flask API (AT ROOT, not in backend/)
├── requirements.txt        ← Python deps (AT ROOT)
└── frontend/
    ├── package.json
    ├── public/
    │   └── index.html
    └── src/
        ├── index.js
        └── App.jsx         ← React dashboard
```

Key: `app.py` and `requirements.txt` are at the REPO ROOT.
The Dockerfile does `COPY . /app/` — copies everything in one shot.
No `COPY backend/` that can fail.

---

## DEPLOY TO RAILWAY

### 1. Push to GitHub

```bash
git init
git add .
git commit -m "sentiment analyzer"
git remote add origin https://github.com/YOUR_USER/sentiment-analyzer.git
git branch -M main
git push -u origin main
```

### 2. Deploy on Railway

1. Go to https://railway.app → Sign in with GitHub
2. "New Project" → "Deploy from GitHub Repo"
3. Pick your repo
4. Railway detects Dockerfile → starts building (~5-8 min)

### 3. Get your URL

Settings → Networking → "Generate Domain"
→ https://your-app-xxxx.up.railway.app

### 4. Done

Open the URL → full dashboard with real-time analysis.

---

## RUN LOCALLY

```bash
# Backend
pip install -r requirements.txt
python app.py
# → http://localhost:5000

# Frontend (separate terminal)
cd frontend
npm install
npm start
# → http://localhost:3000
```

---

## API

| Route | Method | Description |
|-------|--------|-------------|
| `/` | GET | React dashboard |
| `/api/health` | GET | Status |
| `/api/train` | POST | Upload CSV → train models |
| `/api/predict` | POST | Predict sentiment |
| `/api/scrape` | POST | Scrape + analyze |
| `/api/datasets` | GET | Dataset info |

---

## MODELS

| Model | Best Accuracy |
|-------|--------------|
| RoBERTa Transformer | 94.10% (needs torch) |
| Feedforward NN + BoW | 90.32% (paper best) |
| Feedforward NN + TF-IDF | 89.75% |
| Logistic Regression + TF-IDF | 74.18% |
| Random Forest + TF-IDF | 71.93% |
| Naive Bayes + BoW | 70.15% |

---

## TROUBLESHOOTING

**Build fails with memory error:**
requirements.txt is already lightweight (no torch).
RoBERTa runs client-side in the React app.

**Build fails with "not found":**
Make sure app.py and requirements.txt are at repo ROOT.
Run `ls` in your repo — you should see app.py directly.

**App sleeps after 5 min:**
Normal on free tier. First request after sleep takes ~15s.

**Want real RoBERTa on server?**
Upgrade to Railway Pro ($5/mo), add torch + transformers to requirements.txt.
